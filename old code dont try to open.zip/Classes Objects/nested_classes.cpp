// Refer to PDF Pages 51-54
