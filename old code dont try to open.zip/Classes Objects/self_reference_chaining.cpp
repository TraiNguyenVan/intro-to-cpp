// Refer to PDF Pages 38-41
#include <iostream>
#include <string>

using namespace std;

bool leapyear(int y) {
    return (y % 4 == 0 && y % 100 != 0) || (y % 400 == 0);
}

class Date {
    int d, m, y;

public:
    explicit Date(int dd = 0, int mm = 0, int yy = 0);

    Date(const char* s);

    Date& add_day(int n);
    Date& add_month(int n);
    Date& add_year(int n);

    int day() const { return d; };
    int month() const { return m; };
    int year() const;

    void print() const { std::cout << d << "/" << m << "/" << y << std::endl; }
};

Date today{20, 5, 2024};

Date::Date(int dd, int mm, int yy) {
    d = dd ? dd : today.d;
    m = mm ? mm : today.m;
    y = yy ? yy : today.y;
}
Date::Date(const char* s) {
    d = 1;
    m = 1;
    y = 2000;
}
Date& Date::add_day(int n) { 
    if (d == 29 && m == 2 && !leapyear(y+n)) { //beware of February 29
        d = 1;
        m = 3;
    }
    y += n;
    return *this;
}
Date& Date::add_month(int n) { m += n; }
Date& Date::add_year(int n) { y += n; }