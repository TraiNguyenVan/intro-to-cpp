// Refer to PDF Page 9
// Refer to PDF Page 8
struct Date {
    int d, m, y;
    void init(int, int, int);
    void add_year(int n);
    void add_month(int n);
    void add_day(int n);
};
