// Refer to PDF Page 50
