// Refer to PDF Pages 59-61
