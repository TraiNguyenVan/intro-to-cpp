// Refer to PDF Pages 45-48
