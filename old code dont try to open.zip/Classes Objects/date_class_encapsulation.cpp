// Refer to PDF Pages 14-16
class Date {
    int d, m, y;

public:
    void init(int dd, int mm, int yy);
    void add_day(int n);
    void add_month(int n);
    void add_year(int n);
};
void Date::init(int dd, int mm, int yy) {
    d = dd;
    m = mm;
    y = yy;
}
void Date::add_day(int n) { d += n; }
void Date::add_month(int n) { m += n; }
void Date::add_year(int n) { y += n; }

void timewarp(Date& d) {
    // d.y -= 200; //day is private
}

int main() {
    Date dx;
    // dx.m = 3; //error: m is private
    dx.init(25, 3, 2011);
    return 0;
}
