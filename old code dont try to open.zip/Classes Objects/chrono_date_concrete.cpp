// Refer to PDF Pages 55-58
