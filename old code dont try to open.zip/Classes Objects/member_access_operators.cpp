// Refer to PDF Pages 42-44
struct X {
    int f();
    int f2() {
        return m;  // member can be called before definition
    }
    int m;
    static int sm;
};

void user(X x, X* px) {
    // m = 1 // error: there is no m in scope
    x.m = 1;
    // x->m = 1 // error x is not a pointer
    px->m = 1;
    // px.m = 1; // px is a pointer
}

int X::f() {
    return m;  // this is implicit right now
}
int X::sm{7};
// int (X::*) pmf() {&X::f} //this one is not even work

int main() {
    
}