// Refer to PDF Pages 62-63
