// Refer to PDF Pages 6-7
class X {
private:
    int m;

public:
    X(int i) : m{i} {};
    int mf(int i) {
        int old = m;
        m = i;
        return old;
    }
};

X var{7};
int user(X var, X* ptr) {
    int x = var.mf(7);   // via dot
    int y = ptr->mf(9);  // via pointer
    // int z = var.m; // error: can not access private memnber
}