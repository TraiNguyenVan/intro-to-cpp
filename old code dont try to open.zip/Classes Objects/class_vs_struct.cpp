// Refer to PDF Page 17

class Date {
    // private by default
    int d, m, y;

public:
    // public members have to be explicit declared
    void init(int dd, int mm, int yy);
    void add_day(int n);
    void add_month(int n);
    void add_year(int n);
};
void Date::init(int dd, int mm, int yy) {
    d = dd;
    m = mm;
    y = yy;
}
void Date::add_day(int n) { d += n; }
void Date::add_month(int n) { m += n; }
void Date::add_year(int n) { y += n; }

struct Date2 {
    // every memeber are public by default
    int d, m, y;
    void init(int, int, int);
    void add_year(int n);
    void add_month(int n);
    void add_day(int n);
};

Date2 my_birthday;
void f() {
    Date today;
    today.init(16, 10, 1996);
    my_birthday.init(30, 12, 1950);
    Date tomorrow = today;
    tomorrow.add_day(1);
}

void Date2::init(int dd, int mm, int yy) {
    d = dd;
    m = mm;
    y = yy;
}

void Date2::add_day(int n) { d += n; }
void Date2::add_month(int n) { d += m; }
void Date2::add_year(int n) { d += y; }