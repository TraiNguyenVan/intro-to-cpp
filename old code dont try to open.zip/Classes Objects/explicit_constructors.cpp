#include <iostream>

using namespace std;

// Refer to PDF Pages 24-27
class Date {
    int d, m, y;

public:
    // convert number data type to class defined data type
    explicit Date(int dd = 0, int mm = 0, int yy = 0);

    // Non-ambiguous constructor from Page 21
    Date(const char* s);

    void add_day(int n);
    void add_month(int n);
    void add_year(int n);

    void print() const { std::cout << d << "/" << m << "/" << y << std::endl; }
};

Date today{20, 5, 2024};

Date::Date(int dd, int mm, int yy) {
    d = dd ? dd : today.d;
    m = mm ? mm : today.m;
    y = yy ? yy : today.y;
}

// Only declare explicit once
// explicit Date::Date(int dd, int mm, int yy) {
//     d = dd ? dd : today.d;
//     m = mm ? mm : today.m;
//     y = yy ? yy : today.y;
// }

Date::Date(const char* s) {
    d = 1;
    m = 1;
    y = 2000;
}

void Date::add_day(int n) { d += n; }
void Date::add_month(int n) { m += n; }
void Date::add_year(int n) { y += n; }

struct X {
    explicit X();
    explicit X(int, int);
};

int f(X);

int main() {
    // Class examples

    Date d1{15};
    Date d2 = Date{15};
    // Date d3 = {15};  //error
    // Date d4 = 15;    //error

    // Struct examples

    // -------------> error
    // X x1 = {};
    // X x2 = {1,2}

    // -------------> OK
    X x3{};
    X x4 = X{1, 2};

    // -------------> error
    // int i1 = f({});
    // int i2 = f({1, 2});

    // -------------> OK
    int i3 = f(X{});
    int i4 = f(X{1, 2});
    return 0;
}