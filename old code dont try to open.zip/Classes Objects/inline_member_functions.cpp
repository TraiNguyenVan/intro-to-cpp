// Refer to PDF Pages 28-29
#include <iostream>

using namespace std;

class Date {
    int d, m, y;

public:
    explicit Date(int dd = 0, int mm = 0, int yy = 0);

    // Non-ambiguous constructor from Page 21
    Date(const char* s);

    void add_day(int n);
    // inline function (only for short and simple function)
    void add_month(int n) { m += n; };

    void add_year(int n);

    void print() const { std::cout << d << "/" << m << "/" << y << std::endl; }
};

Date today{20, 5, 2024};

Date::Date(int dd, int mm, int yy) {
    d = dd ? dd : today.d;
    m = mm ? mm : today.m;
    y = yy ? yy : today.y;
}
Date::Date(const char* s) {
    d = 1;
    m = 1;
    y = 2000;
}

void Date::add_day(int n) { d += n; }
// to achive same performace as inline
inline void Date::add_month(int n) { m += n; }
void Date::add_year(int n) { y += n; }
int main() { return 0; }