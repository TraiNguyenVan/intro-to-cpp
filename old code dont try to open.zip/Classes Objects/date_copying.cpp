// Refer to PDF Page 13
struct Date {
    int d, m, y;
    void init(int, int, int);
    void add_year(int n);
    void add_month(int n);
    void add_day(int n);
};

Date my_birthday;
void f() {
    Date today;
    today.init(16, 10, 1996);
    my_birthday.init(30, 12, 1950);
    Date tomorrow = today;
    tomorrow.add_day(1);

    Date d1 = my_birthday;
    Date d2{my_birthday};
}

void f2(Date& d) { d = my_birthday; }

void Date::init(int dd, int mm, int yy) {
    d = dd;
    m = mm;
    y = yy;
}

int main() { return 0; }