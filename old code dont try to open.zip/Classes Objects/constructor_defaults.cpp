#include <iostream>

// Refer to PDF Page 23
class Date {
    int d, m, y;

public:
    // Page 23 introduces default arguments. 
    // Note: These defaults make separate Date(), Date(int), and Date(int, int) 
    // from Page 21 ambiguous, so we use this single unified constructor.
    Date(int dd = 0, int mm = 0, int yy = 0);
    
    // Non-ambiguous constructor from Page 21
    Date(const char* s);

    void add_day(int n);
    void add_month(int n);
    void add_year(int n);

    void print() const {
        std::cout << d << "/" << m << "/" << y << std::endl;
    }
};

// Global "today" object used for defaults
Date today {20, 5, 2024};

Date::Date(int dd, int mm, int yy) {
    // Logic from Page 23: if a component is 0, use the value from 'today'
    d = dd ? dd : today.d;
    m = mm ? mm : today.m;
    y = yy ? yy : today.y;
    // Check that date is valid (placeholder)
}

Date::Date(const char* s) {
    // Placeholder implementation for string-based constructor
    d = 1; m = 1; y = 2000;
}

void Date::add_day(int n) { d += n; }
void Date::add_month(int n) { m += n; }
void Date::add_year(int n) { y += n; }

int main() {
    std::cout << "Reference 'today': ";
    today.print();

    Date d1;              // All defaults: today.d, today.m, today.y
    Date d2{15};          // d=15, m=today.m, y=today.y
    Date d3{15, 10};      // d=15, m=10, y=today.y
    Date d4{15, 10, 2025};// Fully specified

    std::cout << "d1 (default): "; d1.print();
    std::cout << "d2 (day 15): "; d2.print();
    std::cout << "d3 (Oct 15): "; d3.print();
    std::cout << "d4 (2025-10-15): "; d4.print();

    return 0;
}
