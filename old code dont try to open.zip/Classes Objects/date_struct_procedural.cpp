// Refer to PDF Page 8
struct Date {
    int d, m, y;
};
void init(Date& d, int, int, int);
void add_year(Date& d, int n);
void add_month(Date& d, int n);
void add_day(Date& d, int n);