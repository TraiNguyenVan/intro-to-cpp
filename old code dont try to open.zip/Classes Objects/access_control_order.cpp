// Refer to PDF Page 18
class Date3 {
public:
    Date3(int dd, int mm, int yy);
    void add_year(int n);  // add n years
private:
    int d, m, y;
};



// pulic and private in whatever order
class Date3 {
public:
    Date3(int dd, int mm, int yy);

private:
    int d, m, y;

public:
    void add_year(int n);  // add n years
};