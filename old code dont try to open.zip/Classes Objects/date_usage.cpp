// Refer to PDF Page 10
struct Date {
    int d, m, y;
    void init(int, int, int);
    void add_year(int n);
    void add_month(int n);
    void add_day(int n);
};

Date my_birthday;
void f() { Date today;
    today.init(16, 10, 1996);
    my_birthday.init(30, 12, 1950);
    Date tomorrow = today;
    tomorrow.add_day(1);
}