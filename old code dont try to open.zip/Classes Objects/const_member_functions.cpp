// Refer to PDF Pages 30-33
#include <iostream>

using namespace std;

class Date {
    int d, m, y;

public:
    explicit Date(int dd = 0, int mm = 0, int yy = 0);

    Date(const char* s);

    void add_day(int n);
    void add_month(int n);
    void add_year(int n);

    // The user function is defined as const and does not change the state of the object's property
    // class.
    int day() const { return d; };
    int month() const { return m; };
    int year() const;

    void print() const { std::cout << d << "/" << m << "/" << y << std::endl; }
};

Date today{20, 5, 2024};

Date::Date(int dd, int mm, int yy) {
    d = dd ? dd : today.d;
    m = mm ? mm : today.m;
    y = yy ? yy : today.y;
}
Date::Date(const char* s) {
    d = 1;
    m = 1;
    y = 2000;
}

void Date::add_day(int n) { d += n; }
void Date::add_month(int n) { m += n; }
void Date::add_year(int n) { y += n; }
int Date::year() const {
    // y++;  // error: attempt to change member value in const function
}

void f(Date& d, const Date& cd) {
    int i = d.year();
    d.add_year(1);
    int j = cd.year();
    // cd.add_year(1); // error: absolutely nonsense
}
int main() { return 0; }