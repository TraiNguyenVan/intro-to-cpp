// Refer to PDF Pages 21-22
class Date {
    int d, m, y;

public:
    Date(int, int, int);  // constructor
    Date(int, int);       // day, month, today year
    Date(int);            // day, today month, year
    Date();               // default date: today
    Date(const char*);    // date in string representation
    void add_day(int n);
    void add_month(int n);
    void add_year(int n);
};
Date::Date(int dd , int mm, int yy) {
    d = dd;
    m = mm;
    y = yy;
}
void Date::add_day(int n) { d += n; }
void Date::add_month(int n) { m += n; }
void Date::add_year(int n) { y += n; }

int main() {
    Date today{4};
    Date july4{"July 4, 1983"};
    Date guy{5, 11};
    Date now;      // same
    Date start{};  // same
    return 0;
}