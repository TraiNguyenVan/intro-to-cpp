// Refer to PDF Pages 34-37
#include <iostream>
#include <string>

using namespace std;

class Date {
    int d, m, y;

public:
    explicit Date(int dd = 0, int mm = 0, int yy = 0);

    Date(const char* s);

    void add_day(int n);
    void add_month(int n);
    void add_year(int n);

    int day() const { return d; };
    int month() const { return m; };
    int year() const;

    string string_rep() const;

    void print() const { std::cout << d << "/" << m << "/" << y << std::endl; }

private:
    mutable bool cache_valid;
    mutable string cache;  // addition data can be modifed along side const main data --> mutable
    void compute_cache() const;  // fill cache
};

Date today{20, 5, 2024};

Date::Date(int dd, int mm, int yy) {
    d = dd ? dd : today.d;
    m = mm ? mm : today.m;
    y = yy ? yy : today.y;
}
Date::Date(const char* s) {
    d = 1;
    m = 1;
    y = 2000;
}

string Date::string_rep() const {
    if (!cache_valid) {
        compute_cache();
        cache_valid = true;
    }
    return cache;
}
void Date::add_day(int n) { d += n; }
void Date::add_month(int n) { m += n; }
void Date::add_year(int n) { y += n; }

void f(Date d, const Date cd) {
    string s1 = d.string_rep();
    string s2 = cd.string_rep();
}

int main() { return 0; }