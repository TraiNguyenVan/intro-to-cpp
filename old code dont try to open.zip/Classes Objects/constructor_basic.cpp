// Refer to PDF Pages 19-20
class Date {
    int d, m, y;

public:
    Date(int dd, int mm, int yy);  // constructor
    void add_day(int n);
    void add_month(int n);
    void add_year(int n);
};
Date::Date(int dd, int mm, int yy) {
    d = dd;
    m = mm;
    y = yy;
}
void Date::add_day(int n) { d += n; }
void Date::add_month(int n) { m += n; }
void Date::add_year(int n) { y += n; }

int main() {
    Date today(26, 03, 2026);
    Date xmas = Date(25, 12, 1990);
    Date tomorrow{17, 03, 2026};
    Date win = Date{30, 04, 1975};

    // Date my_brithday; // initilizer missing
    // Date release1_0(10, 12) //third argument missing
}