# C++ Object-Oriented Programming Notes

A comprehensive guide to C++ fundamentals and Object-Oriented Programming, based on course lectures and practical implementations.

## Table of Contents
1. [02. C++ Basic](#02-c-basic)
2. [03. C++ OO - Classes and Objects](#03-c-oo---classes-and-objects)
3. [04. C++ OO - Class Members & Lifecycle](#04-c-oo---class-members--lifecycle)
4. [05. C++ OO - Operator Overloading](#05-c-oo---operator-overloading)
5. [06. C++ OO - Inheritance and Polymorphism](#06-c-oo---inheritance-and-polymorphism)

---

## 02. C++ Basic

### Introduction and Environment Setup
C++ is a statically typed, compiled, general-purpose programming language created by Bjarne Stroustrup in 1985. It combines C's low-level capabilities with high-level abstractions, supporting procedural, object-oriented, and generic programming paradigms.

- **Compilation Process**: Preprocessing -> Compilation -> Assembly -> Linking.
- **Environment**: Requires a compiler (GCC, Clang, MSVC). Use flags like `-std=c++20` for modern features.
- [Compilation Demo](./Basic/compilation_demo.cpp)

### Basic Syntax and Data Types
- **Minimal Structure**: Every program starts at `main()`. [Example](./Basic/basic_structure.cpp).
- **Namespaces**: Use `std::` for Standard Library components. [Example](./Basic/namespace.cpp).
- **Primitive Types**: `bool`, `char`, `int`, `double`. Check sizes with `sizeof`. [Example](./Basic/data_types.cpp).
- **Initialization**: C++11 uniform initialization `{}` prevents narrowing. [Example](./Basic/value_initialization.cpp).
- **Type Deduction**: `auto` keyword deduces type from initializer. [Example](./Basic/automatic_type_deduction.cpp).
- **Constants**: `const` (runtime) vs `constexpr` (compile-time). [Example](./Basic/constants.cpp).

### Control Flow
- **Operators**: Arithmetic, comparison, compound assignment, and increment/decrement.
- **Loops**: `while`, `do...while`, `for`, and range-based `for`. [Example](./Basic/loops.cpp).

### Arrays, Pointers, and References
- **Pointers**: Store memory addresses (`int* ptr = &var`). [Example](./Basic/arrays_and_pointers.cpp).
- **References**: Aliases for variables (`int& ref = var`). Must be initialized.
- **`nullptr`**: Type-safe null pointer literal (C++11).

### Strings
- **C-Style**: Null-terminated `char` arrays. [Example](./Basic/string_c.cpp).
- **`std::string`**: Modern, safe string management from `<string>`. [Example](./Basic/string_cpp.cpp).

### Functions and Modularity
- **Separation of Concerns**: Declarations in Headers (`.h`), definitions in Source (`.cpp`).
- **RAII Example**: [Vector.h](./Basic/Vector.h) / [Vector.cpp](./Basic/Vector.cpp).
- **Static Assertions**: Compile-time checks. [Example](./Basic/static_assert.cpp).

---

## 03. C++ OO - Classes and Objects

### Class Data Type Concepts
A class encapsulates attributes (data) and behavior (functions) into a single user-defined type.
- **Classification**: Concrete classes, Abstract classes, and Class hierarchies.
- **Access**: Uses `.` (dot) for objects and `->` (arrow) for pointers. [Example](./Basic/class.cpp).

### Class Definition and Encapsulation
- **Namespace**: A class acts as a scope for its members.
- **Access Control**: `public` (interface) vs `private` (implementation details).
- **`struct` vs `class`**: `struct` defaults to `public`; `class` defaults to `private`. [Struct Example](./Basic/struct.cpp).

### Member Function Implementation
- **Scope Resolution (`::`)**: Defines member functions outside the class declaration. [Implementation](./Basic/Vector.cpp).
- **Copying**: Default member-wise copy initialization and assignment.

### Constructors and Object Initialization
- **Constructors**: Same name as class, no return type. [Example](./Basic/Vector.cpp) (see line 8).
- **Overloading**: Support for multiple initialization paths.
- **`explicit`**: Prevents unintended implicit type conversions.

### Member Function Varieties
- **Inline**: Defined inside the class for performance.
- **Const Member Functions**: Guaranteed not to modify object state. [Example](./Basic/Vector.h) (see line 20).
- **`mutable`**: Allows modification within `const` functions (e.g., for caching).

### The `this` Pointer and Self-Reference
- **`this`**: Implicit pointer to the current object.
- **Method Chaining**: Returning `*this` by reference to chain calls.

### Static Members and Nested Classes
- **Static Members**: Shared across all instances of a class. [Example](./Basic/enum_class.cpp) (illustrates scoping).
- **Nested Classes**: Scoped inside another class; can access outer static members.

### Concrete Classes and Helper Functions
- **Operator Overloading**: Custom behavior for `==`, `!=`, `[]`, etc. [Example](./Basic/Vector.cpp) (see line 26).
- **Helper Functions**: Non-member utility functions often kept in the same namespace.

---

## 04. C++ OO - Class Members & Lifecycle

### Constructors and Destructors
- **Lifecycle**: Default, Parameterized, Copy, and Move constructors.
- **Destruction**: Resource cleanup (RAII). [Vector Destructor](./Basic/Vector.cpp) (see line 17).
- **Rule of Zero/Three/Five**: Managing resource-owning classes.

### Member Initialization
- **Initializer Lists**: Preferred way to initialize members. [Example](./Basic/Vector.cpp) (see line 8).
- **Order of Initialization**: Based on declaration order in the class.

### Object Lifecycle
- **Creation/Destruction**: Manual memory management with `new` and `delete`.
- **Special Members**: `= default` and `= delete` for explicit control.

---

## 05. C++ OO - Operator Overloading

### Principles of Overloading
- **Syntax**: `ReturnType operatorOp(Parameters)`.
- **Members vs. Non-members**: Choosing between internal and external operators.

### Common Operators
- **Arithmetic & Relational**: `+`, `-`, `==`, `!=`, `<`, `>`.
- **Assignment**: `=` and compound assignments like `+=`.
- **Stream I/O**: Overloading `<<` and `>>` for custom types.

### Specialized Operators
- **Subscript `[]`**: Accessing elements. [Vector Example](./Basic/Vector.cpp) (see line 26).
- **Function Call `()`**: Making objects "callable" (functors).
- **Type Conversions**: Defining how a class converts to another type.

---

## 06. C++ OO - Inheritance and Polymorphism

### Basic Inheritance
- **Hierarchy**: Base and Derived classes.
- **Access Specifiers**: `public`, `protected`, and `private` inheritance modes.

### Polymorphism and Virtual Functions
- **Dynamic Binding**: Run-time polymorphism via `virtual` functions.
- **vtable**: The mechanism behind dynamic dispatch.
- **Specifiers**: `override` (ensures correct override) and `final` (prevents further inheritance).

### Abstract Classes
- **Interfaces**: Defined using pure virtual functions (`virtual void func() = 0;`).
- **Abstract Base Classes (ABCs)**: Classes that cannot be instantiated.

### Advanced Concepts
- **Multiple Inheritance**: Dealing with the "Diamond Problem" using virtual base classes.
- **Virtual Destructors**: Essential for safe deletion of derived objects via base pointers.
